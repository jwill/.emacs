def first(ls):
    return ls[0] if len(ls) > 0 else None
