
fun example() = "Hello world!"

fun otherFun() = example()

fun yetAnotherFun() = example()