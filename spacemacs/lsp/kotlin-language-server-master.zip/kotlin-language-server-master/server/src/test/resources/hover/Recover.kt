private fun singleExpressionFunction() =
        "Foo"

private fun blockFunction() {
    println("Foo")
}

private fun intFunction() =
        1