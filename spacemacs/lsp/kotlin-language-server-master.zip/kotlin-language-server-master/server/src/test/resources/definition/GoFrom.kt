private object GoFrom {
    fun main() {
        GoFrom.methodInSameFile()
        GoTo.methodInDifferentFile()
    }

    fun methodInSameFile() {

    }
}