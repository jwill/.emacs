class Door
(
val width:Int=3
,val height   :Int = 4
)

class     House

{
    val     door=Door (  )
    
    
    
    val window   = "Window"
}
