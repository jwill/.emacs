private fun completeBackquotedFunction() {
    fu
}

private fun `fun that needs backquotes`() {
}