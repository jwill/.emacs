private fun foo() {
    AnObject
}

private fun bar() {
    AnObject.d
}

private fun dang() {
    AnObject.doh()
}

private object AnObject {
    fun doh() {

    }
}