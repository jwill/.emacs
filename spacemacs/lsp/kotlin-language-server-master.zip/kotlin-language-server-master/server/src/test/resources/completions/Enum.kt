enum class TokenType {
    ILLEGAL;

    companion object {
    }
}

fun tokenTypeFunc() {
    TokenType.
}
