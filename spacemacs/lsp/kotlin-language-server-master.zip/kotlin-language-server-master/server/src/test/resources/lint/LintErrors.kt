private class LintErrors {
    fun foo() {
        return 1
    }
}