private class MiddleOfFunction {
    fun example(p: String): String {
        p.
        return p
    }
}