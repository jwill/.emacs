import java.util.*

private fun completeStatics() {
    Objects.isN
    MyObject.obj
    MyClass.com
    Objects::isN
}

private object MyObject {
    fun objectFun() {
    }
}

private class MyClass {
    companion object {
        fun companionFun() {
        }
    }
}