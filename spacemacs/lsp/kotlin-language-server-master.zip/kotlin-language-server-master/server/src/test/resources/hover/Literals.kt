private fun foo() {
    val stringLiteral = "Foo"
    println(stringLiteral)
}