class OtherFileSymbols() {
    val otherFileProperty = 1

    fun otherFileFunction() {
        val otherFileLocalVariable = 1
    }

    constructor(aConstructorArg: Int): this() {
    }
}