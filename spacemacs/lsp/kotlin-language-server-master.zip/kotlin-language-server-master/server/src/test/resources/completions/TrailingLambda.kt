fun lambdaParameter(x: () -> Unit) {}

fun mixedParameters(a: Int, b: (Int) -> Unit) {}

fun main(args: Array<String>) {
    lamb
    mix
}
