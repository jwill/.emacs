import junit.framework.Assert.assertTrue

private class MainWorkspaceFile {
    fun testFunction() {
        assertTrue(true)
    }
}
