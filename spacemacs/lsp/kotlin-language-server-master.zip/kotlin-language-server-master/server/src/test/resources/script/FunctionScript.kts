fun foo() {
    val first = 1
    val second = 2
}
