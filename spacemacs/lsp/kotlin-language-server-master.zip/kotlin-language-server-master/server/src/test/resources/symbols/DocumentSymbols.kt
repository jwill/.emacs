private class DocumentSymbols() {
    val aProperty = 1

    fun aFunction(aFunctionArg: Int) {
    }

    constructor(aConstructorArg: Int): this() {
    }
}