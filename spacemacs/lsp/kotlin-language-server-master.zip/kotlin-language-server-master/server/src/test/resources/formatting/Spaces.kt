class Test(
    val a: String,
    val b: String
)
