private fun main() {
    SomeC
}

private class SomeConstructor(x: Int) {

}