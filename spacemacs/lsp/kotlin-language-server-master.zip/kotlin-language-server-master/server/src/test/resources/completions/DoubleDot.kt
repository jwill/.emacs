private fun doubleDot(p: String) {
    p.chars().
}