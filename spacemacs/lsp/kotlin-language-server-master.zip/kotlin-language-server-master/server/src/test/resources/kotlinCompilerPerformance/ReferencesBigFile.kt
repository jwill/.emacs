private object ReferencesBigFile {
    fun main() {
        val one = BigFile.max(1, 0)
        println(one)
        println("Foo")
    }
}