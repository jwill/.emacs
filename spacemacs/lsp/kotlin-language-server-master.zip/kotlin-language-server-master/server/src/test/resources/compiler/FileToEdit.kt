private class FileToEdit {
    val someVal = "Foo"
}