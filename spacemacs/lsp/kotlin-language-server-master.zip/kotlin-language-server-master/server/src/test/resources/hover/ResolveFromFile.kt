object ResolveFromFile {
    fun main() {
        ResolveToFile.target()
    }
}