private class CompiledFileExample {
    fun main() {
        val x = 1
        println(x)
    }
}