import java.util.Calendar

fun calendarDemo() {
    val calendar: Calendar = Calendar.getIn
    calendar.firs
    calendar.isLen
}
