private object Caller {
    fun foo() {
    }
}

private object Callee {
    fun bar() {
        println("Bar!")
    }
}