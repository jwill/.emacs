private fun completeQuestionDot(s: String?) {
    s?.
}