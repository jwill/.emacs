object ReferenceFrom {
    fun main() {
        ReferenceTo.foo()
        ReferenceTo + 1
    }
}