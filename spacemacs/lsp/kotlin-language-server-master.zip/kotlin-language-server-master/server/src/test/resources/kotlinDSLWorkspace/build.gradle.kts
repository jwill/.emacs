plugins {
    // TODO: Currently not possible, see https://github.com/gradle/gradle/issues/9830
    // kotlin("jvm") version "$kotlinVersion"
    kotlin("jvm") version "1.3.50"
}

repositories {
    jcenter()
}
