package org.javacs.kt.commands

const val JAVA_TO_KOTLIN_COMMAND = "convertJavaToKotlin"
val ALL_COMMANDS = listOf(
	JAVA_TO_KOTLIN_COMMAND
)
