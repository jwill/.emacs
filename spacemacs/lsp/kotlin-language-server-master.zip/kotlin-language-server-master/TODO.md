# TODO

## Bugs

## Features
- Fix-imports-on-save, default to 'on'
  - See https://godoc.org/golang.org/x/tools/cmd/goimports
- Rename
- .kts support with eval

## Requirements

## Known Issues
